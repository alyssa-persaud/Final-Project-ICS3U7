import java.util.*;
import java.awt.*;
import javax.swing.*;
import javax.swing.border.Border;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
//https://stackoverflow.com/questions/9829319/centering-a-jlabel-in-a-jpanel
//https://www.plus2net.com/java_tutorial/swing-data-transfer.php
//https://stackoverflow.com/questions/27207887/java-jbutton-opening-another-jframe-that-i-can-input-into
class Main implements ActionListener{
  //variable declaration
  private static final Color titleScreen = new Color(0,153,125);
  private static final Color startButton = new Color(50, 82, 123);
  private static final Color playButton = new Color(38,97,156);
  private static final Color exitButton = new Color(207, 58, 36);
  private static final Color leaderBoardButton = new Color(212, 175, 55);
  private static final Color mainMenuColor = new Color(1,68,33);
  private static Font titleFont = new Font("Arial Bold", Font.PLAIN, 38);
  private static Font startFont = new Font("Arial Bold", Font.PLAIN, 25);  
  private static Font menuButtons = new Font("Arial Bold", Font.PLAIN, 23);
  public static GridBagLayout gbLayout = new GridBagLayout();
  public static GridBagConstraints constraints = new GridBagConstraints();
  public static  Container cont = new Container();

  public static void main(String[] args) {
    TitleScreen();
    Hand playersHand =  new Hand();
    Hand hand2 = new Hand();
    Hand hand3 = new Hand();
    Deck deck = new Deck();
    Scanner sc = new Scanner(System.in);
    System.out.println("Enter name for player 1: ");
    String name = sc.nextLine();
    System.out.println("\nShuffling cards...");
    deck.shuffle();
    System.out.println("\nDealing cards...");
    for (int i = 0; i < 8; i++){
      playersHand.addCard(deck.deal());
      hand2.addCard(deck.deal());
      hand3.addCard(deck.deal());
    }
    System.out.println("\n" + name + "'s hand");
    playersHand.print();
    System.out.println("\nPlayer 2's hand");
    hand2.print();
    System.out.println("\nPlayer 3's hand");
    hand3.print();
    System.out.println("\nRemaining cards in deck");
    deck.print();

  }

  public static void TitleScreen(){
    JFrame myFrame = new JFrame("UMO");   //create JFrame
    myFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);   //exit JFrame on close
    myFrame.getContentPane().setBackground(titleScreen);

    myFrame.setSize(800, 600);  //window size
    myFrame.setLocationRelativeTo(null);  //location is default
    myFrame.setVisible(true); //window is visible

    myFrame.setLayout(new BorderLayout());    //layout

    JPanel titlePanel = new JPanel(new FlowLayout());
    titlePanel.setBackground(titleScreen);  //set color
    JLabel title = new JLabel("UMO"); //game title
    title.setFont(titleFont); //set font
    title.setForeground(Color.white); //set title color
    titlePanel.add(title);    //add to panel
    JButton start = new JButton("Start");   //start button
    start.setPreferredSize(new Dimension(100, 50)); //dimension of button
    start.setFont(startFont); //button font
    start.setBackground(startButton); //button color
    start.setForeground(Color.white);   //button font color
    titlePanel.add(start);  //add to panel
    titlePanel.setBorder(BorderFactory.createEmptyBorder(175,350,225,350));   //set border for panel

    start.addActionListener(new Main());

    myFrame.add(titlePanel);  //add to JFrame
    myFrame.setResizable(false);  //window is resizable
  }

  public void actionPerformed(ActionEvent e){
    menu(); //creates new frame when button is clicked
    
  }
  public static void menu(){
    JFrame menuFrame = new JFrame("Main Menu");   //create JFrame
    menuFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);   //exit JFrame on close
    menuFrame.getContentPane().setBackground(titleScreen);

    menuFrame.setSize(800, 600);  //window size
    menuFrame.setLocationRelativeTo(null);  //location is default
    menuFrame.setVisible(true); //window is visible

    JPanel mainMenuPanel = new JPanel(new GridLayout(2, 0));
    mainMenuPanel.setBackground(mainMenuColor); //color
    mainMenuPanel.setBorder   (BorderFactory.createEmptyBorder(0,200,0,200)); //create empty border
    FlowLayout layout = new FlowLayout(); //set layout
    layout.setHgap(10); //gap; horizontal
    layout.setVgap(10); //gap; vertical
    JPanel buttons = new JPanel(layout);  //panel for buttons
    buttons.setBackground(mainMenuColor); //color

    JButton home = new JButton("Home"); //home button
    home.setFont(menuButtons);
    home.setBackground(titleScreen);
    home.setForeground(Color.white);
    home.setPreferredSize(new Dimension(175, 75));

    JButton play = new JButton("Play");   //play button
    play.setFont(menuButtons);
    play.setBackground(playButton);
    play.setForeground(Color.white);
    play.setFont(menuButtons);
    play.setPreferredSize(new Dimension(175, 75));

    JButton exit = new JButton("Exit"); //exit button
    exit.setBackground(exitButton);
    exit.setForeground(Color.white);
    exit.setFont(menuButtons);
    exit.setPreferredSize(new Dimension(175, 75));

//leaderboard button
    JButton leaderboard = new JButton("Leaderboard");
    leaderboard.setBackground(leaderBoardButton);
    leaderboard.setForeground(Color.white);
    leaderboard.setFont(menuButtons);
    leaderboard.setPreferredSize(new Dimension(175, 75));

//add buttons to button panel
    buttons.add(play);  
    buttons.add(leaderboard);
    buttons.add(home);
    buttons.add(exit);

  //panel for main menu
    JPanel unoPanel = new JPanel(new FlowLayout());
    unoPanel.setBackground(mainMenuColor);  //color
    JLabel title = new JLabel("Main Menu"); //game title
    title.setFont(titleFont); //set font
    title.setForeground(Color.white); //set title color
    unoPanel.setBorder(BorderFactory.createEmptyBorder(100, 0, 0, 0));  //empty border created
    unoPanel.add(title);    //add title
    mainMenuPanel.add(unoPanel);  //add panel
    mainMenuPanel.add(buttons);   //add buttons
    menuFrame.add(mainMenuPanel); //add panel to frame
    menuFrame.setResizable(false);  //window is resizable
  }

  }

 