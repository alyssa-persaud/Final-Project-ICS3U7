


// ALYSSA'S TRIAL PLACE FOR TESTING CODE
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.LayoutManager;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.*;
import java.awt.*;

import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.JTextArea;
import javax.swing.border.Border;
import javax.swing.*;

 class MyFrame implements ActionListener {
     private static final Color titleScreen = new Color(0,153,125);
     private static final Color playButton = new Color(38,97,156);
     private static final Color exitButton = new Color(207, 58, 36);
     private static final Color leaderBoardButton = new Color(212, 175, 55);
 private static final Color mainMenuColor = new Color(1,68,33);
  private static final Color darkGreen = new Color(0,153,0);
  private Font titleFont = new Font("Arial Bold", Font.PLAIN, 38);
  private Container cont;
  
  JButton start = new JButton("START");

  public static void TitleScreen(){
    //this.setContentPane(titlePanel);	
    JPanel titlePanel = new JPanel();
		titlePanel.setLayout(new GridLayout(4,1,5,5));
    titlePanel.setBackground(darkGreen);
    JLabel titleName = new JLabel("UNO");
    Box titleText = Box.createHorizontalBox();
    titleText.add(titleName);

  }

  public static void menu(){
     JPanel mainMenuPanel = new JPanel();
	    mainMenuPanel.setBackground(mainMenuColor);
	    JPanel buttons = new JPanel(new GridLayout(4,0));
      
	    JButton home = new JButton("Home");
      home.setBackground(titleScreen);
      home.setForeground(Color.white);

	    JButton play = new JButton("Play");
      play.setBackground(playButton);
      play.setForeground(Color.white);

	    JButton exit = new JButton("Exit");
      exit.setBackground(exitButton);
      exit.setForeground(Color.white);

	    JButton leaderboard = new JButton("Leaderboard");
      leaderboard.setBackground(leaderBoardButton);
      leaderboard.setForeground(Color.white);

	    buttons.add(home);
	    buttons.add(play);
	    buttons.add(exit);
	    buttons.add(leaderboard);
      mainMenuPanel.add(buttons);
  }
  
 /* @Override
  public void painting(Graphics g){
    g.setFont(titleFont);
    g.setColor(Color.white);
    g.drawString("UNO", 120, 50);
  }*/
  
  /*public static void main(String[] args) {
   JFrame myFrame = new JFrame("UNO");  //declare frame
    myFrame.setSize(800, 600);    //set size
    myFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    myFrame.getContentPane().setBackground(darkGreen);
		myFrame.setLocationRelativeTo(null);
    myFrame.setVisible(true);   //visible
    myFrame.TitleScreen();
    myFrame.menu();

  }*/
  
  @Override
  public void actionPerformed(ActionEvent arg0){

  }
  
  
  
 }
  
  /*public static final Color darkGreen = new Color(0,153,0);
  public static final Color white = new Color(0, 0, 0);
  public static final Font buttonFont = new Font("Times New Roman", Font.PLAIN, 14);
  public static Container container;
  public static JFrame myFrame, testFrame;

   TitleScreenHandler titleHandler = new TitleScreenHandler();*/

	
  /*public static void window(){
  /*  myFrame = new JFrame("UNO");  //declare frame
    myFrame.setSize(800, 600);    //set size
    myFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    myFrame.getContentPane().setBackground(darkGreen);
		myFrame.setLocationRelativeTo(null);
    myFrame.setVisible(true);   //visible
    container = myFrame.getContentPane();


    JPanel title = new JPanel();    //panel
    title.setBounds(100, 100, 600, 150);  //title area
    title.setBackground(Color.black);   //title background
    JLabel titleName = new JLabel("UMO");   //title
    titleName.setForeground(Color.white);   //text color
    

    Font titleFont = new Font("Arial Bold", Font.PLAIN, 38);
    titleName.setFont(titleFont);

    JPanel start = new JPanel();
    start.setBounds(300, 400, 200, 100);
    start.setBackground(Color.black);

    JButton startButton = new JButton("START");
    startButton.setBackground(Color.blue);
    startButton.setForeground(Color.white);
    startButton.setFont(buttonFont);
    startButton.addActionListener(titleHandler);

    title.add(titleName);
    start.add(startButton);
    container.add(title);
    container.add(start);
  }


public static void menu(){
  testFrame = new JFrame("TEST");
  testFrame.setSize(1000, 1000);
  testFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
  testFrame.getContentPane().setBackground(white);
	testFrame.setLocationRelativeTo(null);
  testFrame.setVisible(true);
  
  Container container = testFrame.getContentPane();
  JPanel mainText = new JPanel();
  mainText.setBounds(100, 100, 600, 250);
  mainText.setBackground(Color.BLUE);
  container.add(mainText);   

  JTextArea mainArea = new JTextArea();
  mainArea.setBounds(100,100,600,250);
  mainArea.setBackground(Color.black);
  mainArea.setForeground(Color.white);
  mainArea.setFont(buttonFont);
  mainArea.setLineWrap(true);   //wraps text
  mainText.add(mainArea);

}
class TitleScreenHandler implements ActionListener{

  public void actionPerformed(ActionEvent event){

  }
} */
